# Name : Ritesh Sharma
# Roll No : 191IT142

# Importing libraries
import hashlib
import time
import pandas as pd

# Reading dataset
phish_score = pd.read_csv("phish_score.csv", header=None)
# print(phish_score.head())

# dropping column one
phish_score.drop(1, inplace=True, axis=1)
# print(phish_score.head())

# Computing signature database for the given set of URL by using MD5 hash algorithm as signature generator.
start_time = time.time()

for i in phish_score.index:
    result = hashlib.md5((phish_score.at[i, 0]).encode())
    phish_score.at[i, 0] = result.hexdigest()

end_time = time.time()

# Time consumed to generate the signature database for the given URL
total_time = end_time - start_time
print("Time consumed to generate the signature database(in seconds) : ", total_time)

# Storing the generated signature on the output file with the file name 191IT142_IT352_signature_URL_database.txt
phish_score.to_csv('191IT142_IT352_signature_URL_database.txt', header=None, index=None, sep='\t', mode='a')


# Printing the generated signature on the terminal
print(phish_score)

# Function for lookup operation for a given test input
def lookUp(input_url, hex_result):
    with open("191IT142_IT352_signature_URL_database.txt", "r") as a_file:
        for line in a_file:
            if hex_result == line.strip():
                print(input_url)
                print(hex_result)
                print("URL exists")
                with open('output.txt', 'w') as fp:
                    fp.write(input_url)
                    fp.write("\n")
                    fp.write(hex_result)
                    fp.write("\n")
                    fp.write("URL exists")
                    fp.write("\n")
                return
    print("URL does not exist")
    with open('output.txt', 'w') as fp:
        fp.write("URL does not exist")
        fp.write("\n")


# Taking input from user
print("Enter the URL : ", end = "")
input_url = input()
input_url.strip()
result = hashlib.md5(input_url.encode())
hex_result = result.hexdigest()

# Calling lookUp function
lookUp(input_url, hex_result)
