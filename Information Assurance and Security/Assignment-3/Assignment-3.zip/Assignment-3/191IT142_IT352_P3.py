# -----------------------------------------------------
#                Name : Ritesh Sharma
#                Roll No : 191IT142
# -----------------------------------------------------

# Library
import pandas as pd

# Taking input file name from the user at runtime:
print("Enter the input file name :", end = " ")
file_name = input()

dataset = pd.read_csv(file_name + ".csv")
# print(dataset.head(5))

print(dataset.isnull().values.any()) # is any null value in dataset
print(dataset.isnull().values.any().sum()) # count of null values in dataset

# delete row if any column of that row contain null value
dataset = dataset.dropna(how = 'any', axis = 0)

# dataset.shape

total_packet = dataset.shape[0]
total_intrusion = 0

found = "Analyzed Packet is Intrusion Packet"
not_found = "Analyzed Packet is Not-Intrusion Packet"

with open('191IT142_IT352_P3_Output_TC6T.txt', 'w') as fp:
  for i in dataset.index:
    if dataset.at[i,'src'] == dataset.at[i,'dst'] or dataset.at[i,'src'] == '255.255.255.255' or dataset.at[i,'dst'] == '255.255.255.255' or int(dataset.at[i,'bytecount']) < 40 or dataset.at[i,'Protocol'] == 'ICMP':
       total_intrusion = total_intrusion + 1
       print(found)
       fp.write(found)
       fp.write("\n")
       found_detail = ""
       for j in dataset.loc[[i]]:
         found_detail = found_detail + str(((dataset.loc[[i]])[j]).values) + " "
       print(found_detail)
       fp.write(found_detail)
       fp.write("\n")
    else:
      print(not_found)
      fp.write(not_found)
      fp.write("\n")
      not_found_detail = ""
      for j in dataset.loc[[i]]:
        not_found_detail = not_found_detail + str(((dataset.loc[[i]])[j]).values) + " "

      fp.write(not_found_detail)
      print(not_found_detail)
      fp.write("\n")
  print("\n")
  final_ans = "total number of packets checked is = " + str(total_packet) + ", total number of intrusion packets detected is = " + str(total_intrusion)
  print(final_ans)
  fp.write(final_ans)
  fp.write("\n")

