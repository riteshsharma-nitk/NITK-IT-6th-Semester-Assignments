import pandas as pd
name=input()

df=pd.read_csv(name)
total_packets=df.shape[0]
net_intrusion=0

with open("191IT145_IT352_P3_Output_TC6.txt",'w') as file:
    for i in range (0,total_packets):
        if df.at[i,'src'] == df.at[i,'dst'] :
            print("Analyzed Packet is Intrusion Packet")
            file.write("Analyzed Packet is Intrusion Packet")
            file.write('\n')
            s=''
            for y in list(df.columns):
             s+=str(df.iloc[i][y])
             s+=' '
            #  print(df.iloc[i][y],end=' ')
             file.write(str(df.iloc[i][y]))
             file.write(' ')
            #  print('\n')
            file.write('\n')
            net_intrusion+=1
            print(s)
        elif df.iloc[i].bytecount < 40:
            print("Analyzed Packet is Intrusion Packet")
            file.write("Analyzed Packet is Intrusion Packet")
            file.write('\n')
            s=''
            for y in list(df.columns):
             s+=str(df.iloc[i][y])
             s+=' '
            #  print(df.iloc[i][y],end=' ')
             file.write(str(df.iloc[i][y]))
             file.write(' ')
            #  print('\n')
            file.write('\n')
            net_intrusion+=1
            print(s)
        elif str(df.iloc[i].Protocol) == "ICMP":
            print("Analyzed Packet is Intrusion Packet")
            file.write("Analyzed Packet is Intrusion Packet")
            file.write('\n')
            s=''
            for y in list(df.columns):
             s+=str(df.iloc[i][y])
             s+=' '
            #  print(df.iloc[i][y],end=' ')
             file.write(str(df.iloc[i][y]))
             file.write(' ')
            #  print('\n')
            file.write('\n')
            net_intrusion+=1
            print(s)
        elif df.at[i,'src'] == '255.255.255.255' or df.at[i,'dst'] == '255.255.255.255':
            print("Analyzed Packet is Intrusion Packet")
            file.write("Analyzed Packet is Intrusion Packet")
            file.write('\n')
            s=''
            for y in list(df.columns):
             s+=str(df.iloc[i][y])
             s+=' '
            #  print(df.iloc[i][y],end=' ')
             file.write(str(df.iloc[i][y]))
             file.write(' ')
            #  print('\n')
            file.write('\n')
            net_intrusion+=1
            print(s)
        else:
            print("Analyzed Packet is Not-Intrusion Packet")
            file.write("Analyzed Packet is Not-Intrusion Packet")
            file.write("\n")
            s=''
            for y in list(df.columns):
            #   print(df.iloc[i][y],end=' ')
              s+=str(df.iloc[i][y])
              s+=' '
              file.write(str(df.iloc[i][y]))
              file.write(" ")
            file.write('\n')
            print(s)

    print("total number of packets checked is =",total_packets)
    print("total number of intrusion packets detected is =",net_intrusion)
    file.write("total number of packets checked is =")
    file.write(str(total_packets)+'\n')
    file.write("total number of intrusion packets detected is =")
    file.write(str(net_intrusion)+'\n')
    file.close()





        
        

        
 
